// let div = document.querySelector("div")
// console.log(div);
// let id = div.getAttribute("id");
// console.log(id);
// let name = div.getAttribute("name");
// console.log(name);

// let p = document.querySelector("p")
// console.log(p)
// let para = document.querySelector("p")
// console.log(p.getAttribute("class"));

// let para = document.querySelector("p")
// console.log(para.setAttribute("class", "newClass" ));

//node.style
// let div = document.querySelector("div");
// div.style.backgroundColor = "blue"
// div.style.backgroundColor = "powderpink"
// // div.style.visibility="hidden"
// div.style.fontSize = "30px" 
// div.align="center"
// // div.innerText="hey!"


//InsertEl
let newButton = document.createElement("button")
newButton.innerText="click me!"
console.log(newButton)

// let div = document.querySelector("div")
// div.append(newButton) //button at the end

let div = document.querySelector("div")
div.prepend(newButton) //button at the start
console.log(div);

// let div = document.querySelector("div")
// div.before(newButton) //button before
// console.log(div);

// let div = document.querySelector("div")
// div.after(newButton) //button before
// console.log(div);


//for "click me! button"
// let p = document.querySelector("p")
// p.after(newButton) //button before
// console.log(p);

// let p = document.querySelector("p")
// p.before(newButton) //button before
// console.log(p);

// let p = document.querySelector("p")
// p.prepend(newButton) //button before
// console.log(p);

// let p = document.querySelector("p")
// p.append(newButton) //button before
// console.log(p);